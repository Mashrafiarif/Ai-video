import os, math, json, wave, subprocess, random
from pathlib import Path
from array import array
from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageEnhance, ImageFilter, features
import imageio_ffmpeg
HERE=Path(__file__).resolve().parent
OUT=Path(os.environ.get('OUTPUT','output')); OUT.mkdir(exist_ok=True,parents=True)
W=int(os.environ.get('WIDTH','1080')); H=W*16//9; S=W/720; FPS=30
D=float(os.environ.get('SCENE_SECONDS','5')); N=round(D*FPS); D=N/FPS
if not features.check_feature('raqm'): raise RuntimeError('Pillow lacks RAQM Bengali text shaping')
FONT=os.environ.get('BN_FONT','bengali.ttf'); FF=imageio_ffmpeg.get_ffmpeg_exe()
BG='#0b1728'; WHITE='#f7f8fb'; TEAL='#46ebc2'; GOLD='#fbd16a'; RED='#ff7888'; MUTED='#91a9c0'
# Each entry identifies an image, actual topic, text and motion.
SCENES=[
 ('budget','budget','ডলার খরচ করছেন?','ফেসবুকে বিজ্ঞাপন','money'),
 ('skip','feed','একটা সোয়াইপেই স্কিপ!','আপনার বিজ্ঞাপন','scroll'),
 ('why','feed','কিন্তু কেন?','', 'question'),
 ('toy','toy','বাচ্চাদের খেলনা','প্রোডাক্ট দিয়ে শুরু','reveal'),
 ('quality','toy','উন্নত মান','আকর্ষণীয় ডিজাইন','features'),
 ('price','toy','সাশ্রয়ী মূল্য','ফিচার ও দাম','price'),
 ('alternate','toy','একই প্রোডাক্ট','অন্যভাবে শুরু করুন','compare'),
 ('problem','child','আপনার সন্তান কি','মোবাইলে বেশি আসক্ত?','child'),
 ('mobile','child','অভিভাবকের সমস্যা','মোবাইলে অতিরিক্ত সময়','target'),
 ('compare','toy','একই খেলনা। দুইটি হুক।','প্রোডাক্ট বনাম সমস্যা','compare'),
 ('three','feed','ভালো হুকের ৩টি কাজ','আকর্ষণ • প্রাসঙ্গিকতা • কৌতূহল','three'),
 ('attention','feed','১. দৃষ্টি আকর্ষণ','স্ক্রল থামান','spot'),
 ('relevance','child','২. প্রাসঙ্গিকতা','এটা আমার জন্য?','target'),
 ('curiosity','child','৩. কৌতূহল','এর সমাধান কী?','question'),
 ('timer','feed','প্রথম ৩ সেকেন্ড','দেখবে নাকি স্কিপ করবে?','timer'),
 ('reason','feed','বিজ্ঞাপন দেখার কারণ দিন','কাস্টমার নিজে বিজ্ঞাপন খোঁজে না','scroll'),
 ('testing','toy','পুরোনো অ্যাড দেখুন','হুক পরীক্ষা করুন','compare'),
 ('final','feed','আপনি কি থেমে দেখতেন?','নিজের বিজ্ঞাপন যাচাই করুন','question'),
]
assets={k:Image.open(HERE/'assets'/f'{k}.jpg').convert('RGB') for k in ['feed','toy','child','budget']}
RES=Image.Resampling.LANCZOS
fonts={}
def font(size):
    size=round(size*S)
    if size not in fonts:
        f=ImageFont.truetype(FONT,size,layout_engine=ImageFont.Layout.RAQM)
        try: f.set_variation_by_axes([100,750])
        except (OSError,AttributeError): pass
        fonts[size]=f
    return fonts[size]
def box(x,y,w,h): return tuple(round(v*S) for v in (x,y,x+w,y+h))
def pt(x,y): return round(x*S),round(y*S)
def ease(t): return 1-(1-max(0,min(1,t)))**3
def rect(d,x,y,w,h,c,r=20,outline=None):
    if w>0 and h>0: d.rounded_rectangle(box(x,y,w,h),radius=max(1,round(r*S)),fill=c,outline=outline,width=max(1,round(2*S)))
def circle(d,x,y,r,c,outline=None):
    if r>0: d.ellipse(box(x-r,y-r,2*r,2*r),fill=c,outline=outline,width=max(1,round(3*S)))
def line(d,p,c,w=4): d.line([pt(*v) for v in p],fill=c,width=max(1,round(w*S)),joint='curve')
def title(d,s,x,y,size=45,c=WHITE,maxw=620):
    if not s: return
    while size>16 and d.textlength(s,font=font(size))>maxw*S: size-=2
    d.text(pt(x,y),s,font=font(size),fill=c,anchor='mm',stroke_width=0)
def pill(d,s,x,y,w=250,c=TEAL):
    rect(d,x-w/2,y-28,w,56,BG,26,c); title(d,s,x,y,25,c,w-18)
# Precompute softly blurred image-backed scene backgrounds.
backs={}
for k,im in assets.items():
    a=ImageOps.fit(im,(W,H),method=RES).filter(ImageFilter.GaussianBlur(32*S))
    backs[k]=Image.blend(a,Image.new('RGB',(W,H),BG),.79)
masks={}
def photo(canvas,key,x,y,w,h,t,zoom=1.0,drift=0):
    ww,hh=max(1,round(w*S)),max(1,round(h*S)); keymask=(ww,hh)
    src=assets[key]; sx=1+0.10*ease(t/3)+max(0,zoom-1); nw,nh=round(src.width/sx),round(src.height/sx)
    cx=src.width/2+drift*math.sin(t*1.3)*0.04*src.width; cy=src.height/2
    cx=min(src.width-nw/2,max(nw/2,cx)); cy=min(src.height-nh/2,max(nh/2,cy))
    crop=src.crop((round(cx-nw/2),round(cy-nh/2),round(cx+nw/2),round(cy+nh/2)))
    im=ImageOps.fit(crop,(ww,hh),method=Image.Resampling.BICUBIC)
    if keymask not in masks:
        m=Image.new('L',(ww,hh)); ImageDraw.Draw(m).rounded_rectangle((0,0,ww-1,hh-1),radius=min(round(25*S),ww//2,hh//2),fill=255); masks[keymask]=m
    canvas.paste(im,pt(x,y),masks[keymask])
    ImageDraw.Draw(canvas).rounded_rectangle(box(x,y,w,h),radius=round(25*S),outline='#47677d',width=max(1,round(2*S)))
def arrow(d,x,y,x2,y2,c=TEAL):
    line(d,[(x,y),(x2,y2)],c,7); a=math.atan2(y2-y,x2-x)
    for b in [-.55,.55]: line(d,[(x2,y2),(x2-22*math.cos(a+b),y2-22*math.sin(a+b))],c,7)
def render(scene,t,i):
    key,asset,heading,sub,mode=scene; im=backs[asset].copy(); d=ImageDraw.Draw(im)
    a=ease(t/.55); y=275+38*(1-a); p=(math.sin(t*4)+1)/2
    rect(d,50,105,100*a,6,TEAL,3)
    title(d,heading,360,174,48); title(d,sub,360,238,30,GOLD)
    if mode=='compare':
        photo(im,'toy',52-45*(1-a),y+90,300,430,t,drift=1)
        b=ease((t-.4)/.6); photo(im,'child',368+45*(1-b),y+90,300,430,t,drift=-1)
        d=ImageDraw.Draw(im); pill(d,'প্রোডাক্ট',202,y+560,260,RED); pill(d,'সমস্যা',518,y+560,260,TEAL)
        circle(d,360,y+300,38,GOLD); title(d,'VS',360,y+300,26,BG,64)
    elif mode=='three':
        photo(im,asset,70,y,580,420,t); d=ImageDraw.Draw(im)
        for j,label in enumerate(['আকর্ষণ','প্রাসঙ্গিকতা','কৌতূহল']):
            q=ease((t-.28*j)/.5); xx=128+j*232; yy=815+55*(1-q)
            circle(d,xx,yy,39,TEAL if j==0 else GOLD); title(d,['১','২','৩'][j],xx,yy,34,BG); title(d,label,xx,yy+72,27,WHITE,215)
    else:
        photo(im,asset,55,y,610,610,t,zoom=.08*p+1 if mode in ['child','target'] else 1,drift=1)
        d=ImageDraw.Draw(im)
        if mode=='money':
            for j in range(7):
                xx=105+j*78; yy=850-((t*95+j*93)%460)
                rect(d,xx-24,yy-13,48,26,'#288c69',6,GOLD); title(d,'$',xx,yy,23,WHITE,40)
            pill(d,'খরচ চলছেই',360,950,300,GOLD)
        elif mode=='scroll':
            # Independent moving feed cards and swipe arrow.
            for j in range(3):
                yy=375+(j*150-t*145)%450; rect(d,102,yy,170,108,'#142e45',14,MUTED)
                photo(im,'toy',113,yy+9,70,90,t); d=ImageDraw.Draw(im); line(d,[(195,yy+35),(255,yy+35)],WHITE,5); line(d,[(195,yy+57),(240,yy+57)],MUTED,4)
            arrow(d,558,750-100*p,558,530-100*p); pill(d,'স্কিপ',360,950,260,RED)
        elif mode in ('features','price'):
            labels=['মান','ডিজাইন','দাম'] if mode=='features' else ['সাশ্রয়ী','দাম']
            for j,l in enumerate(labels):
                q=ease((t-.4*j)/.5); xx=360+(j-(len(labels)-1)/2)*195; pill(d,l,xx,950+35*(1-q),175,GOLD if j==2 else TEAL)
        elif mode in ('child','target','spot'):
            # Layered focus rings and luminous screen effect; the source character is not rigged.
            xx=360; yy=590; r=115+22*p
            circle(d,xx,yy,r,None,TEAL); circle(d,xx,yy,r+25,None,GOLD)
            if mode=='target': pill(d,'সমস্যাটি পরিচিত?',360,950,350,TEAL)
            elif mode=='spot': arrow(d,570,910,570,735); pill(d,'দেখুন!',360,950,220,TEAL)
            else: pill(d,'মোবাইল আসক্তি?',360,950,345,GOLD)
        elif mode=='timer':
            n=max(1,3-int(t)); circle(d,360,595,100,BG,TEAL); title(d,str(n),360,595,106,GOLD); d.arc(box(360-113,595-113,226,226),start=-90,end=-90+max(0,360*(1-min(t,3)/3)),fill=TEAL,width=round(8*S))
        elif mode=='question':
            circle(d,540,365+25*(1-a),55+8*p,BG,GOLD); title(d,'?',540,365+25*(1-a),68,GOLD)
        else: pill(d,'একটি উদাহরণ',360,950,310,TEAL)
    # Minimal progress cue and bottom clearance for Claude's subtitles.
    rect(d,65,1040,590,5,'#34516b',3); rect(d,65,1040,590*min(1,t/D),5,TEAL,3)
    if t<.12: im=Image.blend(backs[asset],im,ease(t/.12))
    return im
scene_map=[dict(scene=i+1,start_seconds=round(i*D,3),end_seconds=round((i+1)*D,3),animation=s[0],title_bn=s[2],description=s[3]) for i,s in enumerate(SCENES)]
(OUT/'scene_map.json').write_text(json.dumps(scene_map,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'animation_index.txt').write_text('\n'.join(f"{s['start_seconds']:05.1f}–{s['end_seconds']:05.1f}s | {s['animation']} | {s['title_bn']} | {s['description']}" for s in scene_map),encoding='utf-8')
# Save one representative frame of each scene for inspection.
preview=Image.new('RGB',(360*3,640*6),BG)
for i,s in enumerate(SCENES): preview.paste(render(s,min(1.6,D*.7),i).resize((360,640),RES),((i%3)*360,(i//3)*640))
preview.save(OUT/'scene_preview.jpg',quality=90)
proc=subprocess.Popen([FF,'-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-threads','4',str(OUT/'silent.mp4')],stdin=subprocess.PIPE)
try:
    for i,s in enumerate(SCENES):
        print(f'Rendering {i+1}/{len(SCENES)}: {s[0]}',flush=True)
        for f in range(N): proc.stdin.write(render(s,f/FPS,i).tobytes())
finally:
    proc.stdin.close(); status=proc.wait()
if status: raise RuntimeError('FFmpeg failed')
R=44100; audio=array('h')
for i,s in enumerate(SCENES):
    mode=s[-1]; events=[(0,.18,420,'sweep')]
    if mode=='money': events += [(j*.55,.11,650+j*45,'tick') for j in range(1,8)]
    elif mode=='scroll': events += [(j*1.03,.17,540,'sweep') for j in range(1,5)]
    elif mode=='timer': events += [(j,.12,760-j*100,'tick') for j in range(3)]
    elif mode in ('features','price','compare','three'): events += [(.4+j*.4,.12,660+j*100,'tick') for j in range(3)]
    else: events += [(.55,.18,660,'tick')]
    clip=[0.0]*round(D*R)
    for start,length,freq,kind in events:
        off=round(start*R)
        for j in range(max(0,min(round(length*R),len(clip)-off))):
            t=j/R; env=math.sin(math.pi*t/length)**2
            clip[off+j]+=.12*env*math.sin(math.tau*(freq*t+(950*t*t if kind=='sweep' else 0)))
    audio.extend(round(max(-1,min(1,v))*32767) for v in clip)
with wave.open(str(OUT/'animation_sfx.wav'),'wb') as f: f.setparams((1,2,R,0,'NONE','not compressed')); f.writeframes(audio.tobytes())
subprocess.run([FF,'-hide_banner','-loglevel','error','-y','-i',str(OUT/'silent.mp4'),'-i',str(OUT/'animation_sfx.wav'),'-c:v','copy','-c:a','aac','-b:a','160k','-shortest','-movflags','+faststart',str(OUT/'animations.mp4')],check=True)
(OUT/'silent.mp4').unlink()
subprocess.run([FF,'-v','error','-xerror','-i',str(OUT/'animations.mp4'),'-f','null','-'],check=True)
print(f'OK: {len(SCENES)} scenes, {W}x{H}, {len(SCENES)*D:.1f} seconds',flush=True)
